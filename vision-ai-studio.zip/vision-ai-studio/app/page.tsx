import Link from 'next/link'

export default function HomePage() {
  return (
    <main className="min-h-screen bg-[#030309] text-white">
      {/* Nav */}
      <nav className="fixed top-0 left-0 right-0 z-50 border-b border-white/[0.06] bg-[#030309]/80 backdrop-blur-xl">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-brand-500 to-purple-500 flex items-center justify-center font-bold text-sm">V</div>
            <span className="font-semibold text-white">Vision AI Studio</span>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/signin" className="px-4 py-2 rounded-lg text-gray-400 hover:text-white text-sm transition-colors">
              Sign In
            </Link>
            <Link href="/signup"
              className="px-4 py-2 rounded-lg bg-gradient-to-r from-brand-500 to-purple-500 text-white text-sm font-semibold hover:opacity-90 transition-all">
              Get Started Free
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="pt-32 pb-24 px-6 text-center max-w-4xl mx-auto">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-brand-500/10 border border-brand-500/20 text-brand-400 text-xs font-semibold mb-8">
          <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
          India's #1 Export + AI Automation Platform
        </div>
        <h1 className="text-6xl font-black leading-[1.0] tracking-tight mb-6">
          Build Powerful<br/>
          <span className="gradient-text">AI Workflows</span><br/>
          <span className="text-gray-400 font-light">In 24 Hours</span>
        </h1>
        <p className="text-gray-400 text-lg max-w-2xl mx-auto mb-10 leading-relaxed">
          From Lead Automation to Export Documentation — Vision AI Studio builds custom AI workflows for your business. No code. No complexity. Pure results.
        </p>
        <div className="flex items-center justify-center gap-4">
          <Link href="/signup"
            className="px-8 py-4 rounded-xl bg-gradient-to-r from-brand-500 to-purple-500 text-white font-bold text-base hover:opacity-90 active:scale-95 transition-all shadow-lg shadow-brand-500/30">
            Start Free Trial →
          </Link>
          <Link href="/signin"
            className="px-8 py-4 rounded-xl border border-white/10 text-white font-semibold text-base hover:bg-white/5 transition-all">
            Sign In
          </Link>
        </div>
        <p className="text-gray-600 text-sm mt-4">24-hour free trial · No credit card required</p>
      </section>

      {/* Workflow grid (no prices — login to see) */}
      <section className="max-w-6xl mx-auto px-6 pb-24">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-3">All Workflow Categories</h2>
          <p className="text-gray-400">Sign in to see pricing and request workflows</p>
        </div>
        <div className="grid grid-cols-3 gap-5">
          {[
            { icon: '🎯', name: 'Lead Automation', desc: 'Auto-capture and nurture leads via WhatsApp, Email & CRM.' },
            { icon: '📦', name: 'Export Documentation AI', desc: 'Invoice, Packing List, HS Code, COO — zero errors.' },
            { icon: '🤖', name: 'AI Support Bot', desc: '24/7 intelligent customer support + voice agent.' },
            { icon: '💰', name: 'Sales Automation', desc: 'Cart recovery, payment links, invoice generation.' },
            { icon: '🎬', name: 'Content Automation', desc: 'Reels, captions, hashtags, auto DM replies.' },
            { icon: '🎙️', name: 'AI Voice Agent', desc: 'Call handling, lead capture, follow-up automation.' },
          ].map(wf => (
            <div key={wf.name}
              className="bg-white/[0.04] border border-white/[0.08] rounded-2xl p-6
                         hover:border-brand-500/30 transition-all group">
              <div className="text-3xl mb-4">{wf.icon}</div>
              <h3 className="text-white font-semibold mb-2">{wf.name}</h3>
              <p className="text-gray-500 text-sm mb-4">{wf.desc}</p>
              <Link href="/signup"
                className="text-brand-400 text-sm font-medium hover:text-brand-300 transition-colors">
                Login to see pricing →
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-white/[0.06] py-20 px-6 text-center">
        <h2 className="text-3xl font-bold mb-4">Ready to Automate Your Business?</h2>
        <p className="text-gray-400 mb-8">Join 50+ businesses already using Vision AI Studio</p>
        <Link href="/signup"
          className="inline-flex items-center px-8 py-4 rounded-xl bg-gradient-to-r from-brand-500 to-purple-500
                     text-white font-bold hover:opacity-90 transition-all shadow-lg shadow-brand-500/30">
          Start Free Today →
        </Link>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/[0.06] py-8 px-6">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <span className="text-gray-500 text-sm">© 2026 Vision AI Studio · Built by Karishma Kumari</span>
          <div className="flex gap-6">
            {['Privacy', 'Terms', 'Contact'].map(l => (
              <Link key={l} href="#" className="text-gray-500 text-sm hover:text-white transition-colors">{l}</Link>
            ))}
          </div>
        </div>
      </footer>
    </main>
  )
}
